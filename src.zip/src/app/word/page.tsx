"use client"

import WordCard from "@/components/WordCard"
import { useSession } from "next-auth/react"
import { useState,useEffect } from "react"

export default function WordsMain() {
// 데이터 베이스 에서 단어 가져오기
    const url = "http://localhost:8000/"
    
    const [words, setWords] = useState([]);
    useEffect(() => {
        const fetchWords = async() =>{
            const response = await fetch(url+"words/");
            const data = await response.json();
            setWords(data);
        };
        fetchWords();
    }, []);
    
    const {data: session} = useSession();
    const userId = session?.user?.email ?? "guest"
    const [wordName, setWordName]= useState("");
    const [example1, setExample1]= useState("");
    const [example2, setExample2]= useState("");

    const handlePost = async() =>{
        if (!userId){
            alert("로그인이 필요합니다.");
            return;
        }
        if (!wordName.trim()){
            alert("단어를 입력해주세요");
            return;
        }

        const response = await fetch(url+"words/", {
            method:"POST",
            headers:{
                "Content-Type":"application/json",
            },
            body: JSON.stringify({
                word_name: wordName,
                word_content:"",
                user_id: userId,
                examples:[
                    { word_example_content: example1},
                    { word_example_content: example2},
                ],
            }),
        });

        const data = await response.json();
        console.log("응답 결과:", data);
        alert("단어가 등록되었습니다!");

        setWordName("");
        setExample1("");
        setExample2("");
    };
// 카드를 클릭하면 단어 페이지로 이동
    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">단어 등록</h2>
            <input type="text" placeholder="단어 입력" value={wordName} onChange={(e)=>setWordName(e.target.value)} className="w-full px-3 py-2 rounded" />
            <input type="text" placeholder="예시 1" value={example1} onChange={(e)=>setExample1(e.target.value)} className="w-full px-3 py-2 rounded" />
            <input type="text" placeholder="예시 2" value={example2} onChange={(e)=>setExample2(e.target.value)} className="w-full px-3 py-2 rounded" />
        
            <button onClick={handlePost} className="bg-blue-500 text-white px-4 py-2 rounded">
                단어 등록하기 
            </button>
            <WordList />
            {/* {words.map((word) => (
                <WordCard 
                key={word.id}
                word={word.word_name} 
                meaning={word.word__content || "설명이 없습니다."}
                 />
            ))} */}
            
        </div>
    )
}

interface Example {
    word_example_content: string;
    example_sequence: number;
  }
  
  interface Word {
    words_id: number;
    word_name: string;
    word_content: string;
    user_id: string;
    word_created_time: string;
    word_count: number;
    examples: Example[];
  }
  
  export function WordList() {
    const [words, setWords] = useState<Word[]>([]);
  
    useEffect(() => {
      const fetchWords = async () => {
        try {
          const res = await fetch('http://localhost:8000/words/words/');
          const data = await res.json();
          setWords(data); // 배열로 들어오는지 확인 필요
          console.log('불러온 단어:', data);
        } catch (error) {
          console.error('데이터 불러오기 실패:', error);
        }
      };
  
      fetchWords();
    }, []);
  console.log("words 배열 검사:", words); 
  words.forEach((word, idx) => {
    console.log(`word[${idx}]`, word.words_id);
  });
    return (
        <div className="p-6 space-y-4">
        <h1 className="text-2xl font-bold mb-4">📘 단어 목록</h1>
        {words.map((words) => (
          <WordCard
            key={words.words_id}
            words_id={words.words_id}
            word_name={words.word_name}
            word_content={words.word_content}
            user_id={words.user_id}
          />
        ))}
      </div>
    );
  }