'use client'

import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { useState } from 'react'

export default function NewWorkPage() {
  const router = useRouter()
  const { data: session } = useSession()
  const [title, setTitle] = useState('')

  const handleCreate = async () => {
    try {
      const res = await fetch('http://localhost:8000/works/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          works_title: title,
          user_id: session?.user?.email,
        }),
      })

      if (!res.ok) throw new Error('작품 생성 실패')
      const result = await res.json()
      const newWorkId = result.works_id

      // works/ 페이지로 돌아가자
      router.push(`/works`)
    } catch (error) {
      console.error(error)
      alert('작품 생성 실패')
    }
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h1 className="text-2xl font-bold mb-4">작품 추가</h1>
      <input
        type="text"
        placeholder="작품 제목을 입력하세요"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="border p-2 rounded w-full mb-4"
      />
      <button
        onClick={handleCreate}
        className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
      >
        생성하기
      </button>
    </div>
  )
}
