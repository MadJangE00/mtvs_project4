'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';

interface Episode {
  episode_id: number;
  episode_content: string;
  works_id: number;
}

interface WorkDetail {
  works_id: number;
  works_title: string;
  user_id: string;
  worlds: any[];
  characters: any[];
  plannings: any[];
  episodes: Episode[];
}

export default function WorkDetailPage() {
  const { work_id } = useParams() as { work_id: string };
  const [work, setWork] = useState<WorkDetail | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchWorkDetail = async () => {
    try {
      const res = await fetch(`http://localhost:8000/works/${work_id}/work`);
      if (!res.ok) throw new Error('API 요청 실패');
      const data = await res.json();
      setWork(data);
    } catch (error) {
      console.error('작품 정보 불러오기 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (work_id) {
      fetchWorkDetail();
    }
  }, [work_id]);

  if (loading) return <p className="text-center text-gray-500">로딩 중...</p>;
  if (!work) return <p className="text-center text-red-500">작품을 불러오지 못했습니다.</p>;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-2xl font-bold mb-6">🎬 {work.works_title}</h1>

      <div className="grid grid-cols-3 gap-4 mb-8">
        <button className="py-3 bg-white border rounded hover:bg-gray-100 font-semibold">
          <Link href={`/works/plannings`}>기획 설정</Link>
        </button>
        <button className="py-3 bg-white border rounded hover:bg-gray-100 font-semibold">
          <Link href={`/works/worlds`}>세계관 설정</Link>
        </button>
        <button className="py-3 bg-white border rounded hover:bg-gray-100 font-semibold">
          <Link href={`/works/${work_id}/characters`}>캐릭터 설정</Link>
        </button>
      </div>

      <hr className="mb-6" />

      <h2 className="text-lg font-semibold mb-4">📘 에피소드 목록</h2>
      <div className="grid grid-cols-4 gap-4">
        {work.episodes.map((ep) => (
          <Link
            key={ep.episode_id}
            href={`/works/${work_id}/episodes/${ep.episode_id}`}
            className="bg-white p-3 rounded shadow-sm hover:bg-gray-100 block text-center"
          >
            EP. {ep.episode_id}
          </Link>
        ))}
      </div>

      <div className="mt-10 text-center">
        <Link href={`/works/${work_id}/episodes/new`}>
          <button className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
            ➕ 에피소드 추가
          </button>
        </Link>
      </div>
    </div>
  );
}
