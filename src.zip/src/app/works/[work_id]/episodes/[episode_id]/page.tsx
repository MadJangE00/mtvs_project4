'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';

interface Episode {
  episode_id: number;
  works_id: number;
  episode_content: string;
}

export default function EpisodeDetailPage() {
  const { work_id, episode_id } = useParams() as {
    work_id: string;
    episode_id: string;
  };

  const [episode, setEpisode] = useState<Episode | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEpisode = async () => {
      try {
        const res = await fetch(`http://localhost:8000/episodes/${work_id}/${episode_id}`);
        const data = await res.json();
        setEpisode(data);
      } catch (err) {
        console.error('에피소드 불러오기 실패:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchEpisode();
  }, [work_id, episode_id]);

  if (loading) return <div className="p-6">로딩 중...</div>;
  if (!episode) return <div className="p-6 text-red-500">에피소드를 찾을 수 없습니다.</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-2xl font-bold mb-4">EP. {episode.episode_id}</h1>
      <div className="bg-white p-4 rounded shadow">
        <p className="text-gray-800 whitespace-pre-line">{episode.episode_content}</p>
      </div>
    </div>
  );
}
